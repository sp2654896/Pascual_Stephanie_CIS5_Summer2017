/* 
 * File:   main.cpp
 * Author: Stephanie Pascual
 * Created on June 24, 2017, 12:30 PM
 * Purpose:  Write a program that displays the following patterns on a screen;
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist
int main() 
{
    cout << "    *\n"
  << "   ***\n"
  << "  *****\n"
  << " *******\n\n";
    
    return 0;
}


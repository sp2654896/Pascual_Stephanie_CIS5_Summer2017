/* 
 * File:   main.cpp
 * Author: Stephanie Pascual
 * Created on June 25, 2017, 6:00 PM
 * Purpose:  Write a program that stores integers 50 and 100 in variables, and stores the sum of these two in a variable named total.
 */


#include <iostream> 
#include <iomanip>      
using namespace std; 

int main()
{
    
     int num1=50,
     num2=100,
     total;
     
     total= num1 + num2;
     
     cout << "the sum of" << num1 << " + " << num2 << "=" << total << endl;
     
     cout << endl;
     
     }



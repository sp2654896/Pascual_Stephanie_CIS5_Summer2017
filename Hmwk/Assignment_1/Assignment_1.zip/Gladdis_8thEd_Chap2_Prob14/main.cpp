/* 
 * File:   main.cpp
 * Author: Stephanie Pascual
 * Created on June 24, 2017, 11:00 AM
 * Purpose:  Write personal information each on a seperate line
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main() 
{
    cout << "Stephanie Pascual \n"
  << "6296 Pathfinder Rd, Riverside, CA 92504 \n"
  << "951-231-4080 \n"
  << "Engineering \n\n";
    
    return 0;
}

